import heroImg from "./hero.png";
import aboutImg from "./explore.png";

import planImg1 from "./about.png";
import planImg2 from "./about5.png";
import planImg3 from "./about9.png";
import planImg4 from "./about10.png";

import trainerImg1 from "./trainer1.png";
import trainerImg2 from "./trainer2.png";
import trainerImg3 from "./trainer3.png";
import trainerImg4 from "./trainer4.png";


import sponsorImg1 from "./sponsor1.png";
import sponsorImg2 from "./sponsor2.png";
import sponsorImg3 from "./sponsor3.png";
import sponsorImg4 from "./sponsor4.png";


import error from "./error1.png";

import exercisePng from "./exercise.png";

import review1 from "./review1.jpg";
import review2 from "./review2.jpg";
import review3 from "./review3.jpg";
import review4 from "./review4.jpg";

import userImg from "./user.png";

import planImg from "./plan_img.png";


export {heroImg, aboutImg, planImg1, planImg2, planImg3, planImg4, trainerImg1, trainerImg2, trainerImg3, trainerImg4, error, sponsorImg1, sponsorImg2, sponsorImg3, sponsorImg4, exercisePng, review1, review2, review3, review4, userImg, planImg};